This is a overview of the file system.
Here are the files incldudes which we used for the arduino, calculations and diagrams to eplain the code.

Arduino
-------->Librarys
-------------------->Dynamixel_Serial-master.zip
-------------------->MatrixMath-master.zib
-------------------->SoftwareSerial.zip
-------->sources
-------------------->ArduinoCodeWithStringControll_V3_for_	[Main code]
-------------------->SimpleAngleMover				[for verifying the calulated]
dynamics
-------->DyCalculations.mw
-------->Dynamics_Simulation.m
-------->Link1_Inertia.JPG
--------Link2_Inertia.JPG
Kinematics
-------->Calculations.m
-------->CrustCrawler_simulation.m
flowchart
-------->FloatChart_apk.png
-------->FloatChart_arduino.png
ReadMe.txt


(c) G365